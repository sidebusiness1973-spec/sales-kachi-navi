import SwiftUI
enum SalesPage: String, CaseIterable, Identifiable {
    case home = "ホーム", customers = "顧客・案件", followUps = "再連絡", scripts = "トーク集", people = "担当者管理", team = "担当者別集計", pro = "Personal Pro", settings = "設定・出力"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .home: "chart.bar.xaxis"
        case .customers: "person.2"
        case .followUps: "calendar.badge.clock"
        case .scripts: "text.bubble"
        case .team: "chart.bar.doc.horizontal"
        case .people: "person.crop.rectangle.stack"
        case .pro: "star.circle.fill"
        case .settings: "gearshape"
        }
    }
}
struct ContentView: View {
    @Environment(StoreKitManager.self) private var store
    @State private var page: SalesPage? = .home
    @State private var preferredColumn: NavigationSplitViewColumn = .detail
    @State private var showProRequired = false
    var body: some View {
        NavigationSplitView(preferredCompactColumn: $preferredColumn) {
            List(SalesPage.allCases, selection: pageSelection) { item in
                Label(item.rawValue, systemImage: item.icon).tag(item)
            }
            .navigationTitle("営業マン勝ちナビ")
        } detail: {
            NavigationStack {
                switch page ?? .home {
                case .home: DashboardView()
                case .customers: CustomersView()
                case .followUps: FollowUpsView()
                case .scripts: ScriptsView()
                case .team: TeamReportView()
                case .people: SalesPeopleView()
                case .pro: PersonalProView()
                case .settings: SettingsView()
                }
            }
        }
        .tint(.teal)
        .alert("この機能はPersonal Proで利用できます", isPresented: $showProRequired) {
            Button("Personal Proを見る") { page = .pro }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("担当者別の詳細KPI、成果単価、詳細な期間分析はPersonal Proで利用できます。")
        }
    }

    private var pageSelection: Binding<SalesPage?> {
        Binding(
            get: { page },
            set: { requestedPage in
                guard requestedPage != .team || store.isPro else {
                    showProRequired = true
                    return
                }
                page = requestedPage
            }
        )
    }
}
