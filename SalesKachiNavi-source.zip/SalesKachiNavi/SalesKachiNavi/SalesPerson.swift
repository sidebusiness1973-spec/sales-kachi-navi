import Foundation
import SwiftData

@Model
final class SalesPerson {
    var id: UUID = UUID()
    var createdAt: Date = Date()

    // 基本情報
    var name: String = ""
    var department: String = ""
    var role: String = ""
    var email: String = ""

    // 利用状態
    var isActive: Bool = true

    // 成果単価
    var appointmentUnitPrice: Double = 0
    var meetingUnitPrice: Double = 0
    var orderUnitPrice: Double = 0

    init(
        name: String = "",
        department: String = "",
        role: String = "",
        email: String = "",
        isActive: Bool = true,
        appointmentUnitPrice: Double = 0,
        meetingUnitPrice: Double = 0,
        orderUnitPrice: Double = 0
    ) {
        self.name = name
        self.department = department
        self.role = role
        self.email = email
        self.isActive = isActive
        self.appointmentUnitPrice = appointmentUnitPrice
        self.meetingUnitPrice = meetingUnitPrice
        self.orderUnitPrice = orderUnitPrice
    }
}
