import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct ExcelDocument: FileDocument {
    static var readableContentTypes: [UTType] { [UTType(filenameExtension: "xlsx") ?? .data] }
    var data: Data
    init(data: Data = Data()) { self.data=data }
    init(configuration: ReadConfiguration) throws { data=configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

// Small, dependency-free OOXML writer. All cells are literal inline strings, never formulas.
enum ExcelExport {
    static func workbook(sheets: [(String, [[String]])]) -> Data {
        var files: [(String, Data)] = []
        func add(_ name: String, _ text: String) { files.append((name, Data(text.utf8))) }
        let prefix="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        add("[Content_Types].xml", prefix + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" + sheets.indices.map { "<Override PartName=\"/xl/worksheets/sheet\($0+1).xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }.joined() + "</Types>")
        add("_rels/.rels", prefix + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        add("xl/workbook.xml", prefix + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>" + sheets.enumerated().map { i, sheet in "<sheet name=\"\(xml(sheet.0))\" sheetId=\"\(i+1)\" r:id=\"rId\(i+1)\"/>" }.joined() + "</sheets></workbook>")
        add("xl/_rels/workbook.xml.rels", prefix + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + sheets.indices.map { "<Relationship Id=\"rId\($0+1)\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet\($0+1).xml\"/>" }.joined() + "</Relationships>")
        for (i, sheet) in sheets.enumerated() {
            let rows=sheet.1.enumerated().map { row, values in
                "<row r=\"\(row+1)\">" + values.enumerated().map { col, value in
                    "<c r=\"\(column(col))\(row+1)\" t=\"inlineStr\"><is><t xml:space=\"preserve\">\(xml(value))</t></is></c>"
                }.joined() + "</row>"
            }.joined()
            add("xl/worksheets/sheet\(i+1).xml", prefix + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>" + rows + "</sheetData></worksheet>")
        }
        return zip(files)
    }
    static func xml(_ text: String) -> String {
        let clean=String(String.UnicodeScalarView(text.unicodeScalars.filter { $0.value == 9 || $0.value == 10 || $0.value == 13 || (32...0xD7FF).contains($0.value) || (0xE000...0xFFFD).contains($0.value) || (0x10000...0x10FFFF).contains($0.value) }))
        return clean.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;").replacingOccurrences(of: "'", with: "&apos;")
    }
    static func column(_ n: Int) -> String {
        var n=n+1, result=""
        while n > 0 { n-=1; result=String(UnicodeScalar(65+n%26)!) + result; n/=26 }
        return result
    }
    static func crc32(_ data: Data) -> UInt32 {
        var crc=UInt32.max
        for byte in data { crc ^= UInt32(byte); for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xEDB88320 : 0) } }
        return ~crc
    }
    private static func zip(_ files: [(String, Data)]) -> Data {
        var output=Data(), central=Data()
        func word(_ n: UInt16, _ data: inout Data) { data.append(UInt8(truncatingIfNeeded:n)); data.append(UInt8(truncatingIfNeeded:n>>8)) }
        func dword(_ n: UInt32, _ data: inout Data) { word(UInt16(truncatingIfNeeded:n), &data); word(UInt16(truncatingIfNeeded:n>>16), &data) }
        for (name, content) in files {
            let filename=Data(name.utf8), crc=crc32(content), size=UInt32(content.count), offset=UInt32(output.count)
            dword(0x04034b50, &output); word(20, &output); word(0, &output); word(0, &output)
            word(0, &output); word(33, &output); dword(crc, &output); dword(size, &output); dword(size, &output)
            word(UInt16(filename.count), &output); word(0, &output); output.append(filename); output.append(content)
            dword(0x02014b50, &central); word(20, &central); word(20, &central); word(0, &central); word(0, &central)
            word(0, &central); word(33, &central); dword(crc, &central); dword(size, &central); dword(size, &central)
            word(UInt16(filename.count), &central); word(0, &central); word(0, &central); word(0, &central); word(0, &central)
            dword(0, &central); dword(offset, &central); central.append(filename)
        }
        let offset=UInt32(output.count); output.append(central)
        dword(0x06054b50, &output); word(0, &output); word(0, &output)
        word(UInt16(files.count), &output); word(UInt16(files.count), &output)
        dword(UInt32(central.count), &output); dword(offset, &output); word(0, &output)
        return output
    }
}
