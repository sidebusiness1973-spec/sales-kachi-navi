import Foundation

extension SalesActivity {
    /// Called once when recording a new activity, never when a person's prices change.
    func captureSalesPerson(_ person: SalesPerson, at timestamp: Date = Date()) {
        guard pricesCapturedAt == nil else { return }
        salesPersonID = person.id
        salesPersonNameSnapshot = person.name
        appointmentPriceSnapshot = person.appointmentUnitPrice
        meetingPriceSnapshot = person.meetingUnitPrice
        orderPriceSnapshot = person.orderUnitPrice
        pricesCapturedAt = timestamp
    }
    var hasPriceSnapshot: Bool {
        pricesCapturedAt != nil && [appointmentPriceSnapshot, meetingPriceSnapshot, orderPriceSnapshot].allSatisfy {
            guard let price = $0 else { return false }
            return price.isFinite && price >= 0 && price <= 1_000_000_000
        }
    }
    var countsAsAppointment: Bool { kind == "アポ" || (kind == "電話" && appointment) }
    var reward: Decimal {
        guard hasPriceSnapshot else { return 0 }
        return (countsAsAppointment ? SalesKPI.decimal(appointmentPriceSnapshot!) : 0)
            + (kind == "商談" ? SalesKPI.decimal(meetingPriceSnapshot!) : 0)
            + (kind == "受注" ? SalesKPI.decimal(orderPriceSnapshot!) : 0)
    }
}

struct SalesMetrics {
    var calls = 0, connections = 0, decisionContacts = 0, hearings = 0
    var appointments = 0, phoneAppointments = 0, meetings = 0, orders = 0
    var records = 0, missingPrices = 0
    var appointmentReward: Decimal = 0, meetingReward: Decimal = 0, orderReward: Decimal = 0
    var reward: Decimal { appointmentReward + meetingReward + orderReward }
    init(_ activities: [SalesActivity]) {
        for a in activities where a.isEffective {
            records += 1
            if a.kind == "電話" {
                calls += 1
                if a.connected { connections += 1 }
                if a.decisionContact { decisionContacts += 1 }
                if a.hearing { hearings += 1 }
                if a.appointment { phoneAppointments += 1 }
            }
            if a.countsAsAppointment { appointments += 1 }
            if a.kind == "商談" { meetings += 1 }
            if a.kind == "受注" { orders += 1 }
            if !a.hasPriceSnapshot { missingPrices += 1; continue }
            if a.countsAsAppointment { appointmentReward += SalesKPI.decimal(a.appointmentPriceSnapshot!) }
            if a.kind == "商談" { meetingReward += SalesKPI.decimal(a.meetingPriceSnapshot!) }
            if a.kind == "受注" { orderReward += SalesKPI.decimal(a.orderPriceSnapshot!) }
        }
    }
    func rate(_ numerator: Int, _ denominator: Int) -> String {
        denominator == 0 ? "—" : String(format: "%.1f%%", Double(numerator) / Double(denominator) * 100)
    }
}
struct SalesReportGroup: Identifiable {
    let id: String
    let name: String
    let status: String
    let metrics: SalesMetrics
}
enum SalesKPI {
    static let definitions = "取り消し・訂正済みの旧版を除いた有効な活動だけを集計します。架電・接続・担当者接続・ヒアリングは電話の記録件数。アポは電話のアポ獲得または種別「アポ」の件数（同一記録は1件）。商談・受注は各種別の記録件数です。同じ成果を複数回記録すると重複集計されます。電話アポ率＝電話アポ÷架電数。受注／商談比率は期間内の件数比で、同一案件の成約率ではありません。顧客の進捗変更だけでは成果は発生しません。成果金額は記録時単価の合計（税・源泉徴収等の調整前）です。単価記録なしの旧活動は件数だけに含めます。"
    static func decimal(_ value: Double) -> Decimal {
        Decimal(string: String(value), locale: Locale(identifier: "en_US_POSIX")) ?? 0
    }
    static func number(_ value: Decimal) -> String { NSDecimalNumber(decimal: value).stringValue }
    static func money(_ value: Decimal) -> String { number(value) + "円" }
    static func validPrices(_ p: SalesPerson) -> Bool {
        [p.appointmentUnitPrice, p.meetingUnitPrice, p.orderUnitPrice].allSatisfy { $0.isFinite && $0 >= 0 && $0 <= 1_000_000_000 }
    }
    static func groups(_ activities: [SalesActivity], people: [SalesPerson]) -> [SalesReportGroup] {
        let activities = activities.filter(\.isEffective)
        let ids = Set(people.map(\.id)).union(activities.compactMap(\.salesPersonID))
        let grouped = Dictionary(grouping: activities) { $0.salesPersonID }
        let peopleByID = Dictionary(grouping: people, by: \.id)
        var result: [SalesReportGroup] = []
        for id in ids {
            let person: SalesPerson? = peopleByID[id]?.first
            let records: [SalesActivity] = grouped[Optional(id)] ?? []
            let latest = records.max { $0.date < $1.date }
            let name: String = person?.name ?? latest?.salesPersonNameSnapshot ?? "名称不明"
            let status: String = person == nil ? "登録情報なし" : (person!.isActive ? "有効" : "無効")
            result.append(SalesReportGroup(id: id.uuidString, name: name, status: status, metrics: SalesMetrics(records)))
        }
        result.sort { $0.name == $1.name ? $0.id < $1.id : $0.name < $1.name }
        result.append(SalesReportGroup(id: "unassigned", name: "未割当", status: "旧記録など", metrics: SalesMetrics(grouped[nil] ?? [])))
        return result
    }
    static func rows(_ activities: [SalesActivity], people: [SalesPerson], period: String) -> [[String]] {
        let header = ["集計期間", "担当者ID", "担当者", "状態", "活動数", "架電", "接続", "担当者接続", "ヒアリング", "電話アポ", "アポ計", "商談", "受注", "接続率", "電話アポ率", "受注／商談比率", "担当者アポ成果金額（円）", "担当者商談成果金額（円）", "担当者受注成果金額（円）", "担当者成果金額計（円）", "単価記録なし件数"]
        let team = SalesReportGroup(id: "team", name: "チーム全体", status: "未割当を含む", metrics: SalesMetrics(activities))
        return [header] + ([team] + groups(activities, people: people)).map { group in
            let m = group.metrics
            return [period, group.id, group.name, group.status, String(m.records), String(m.calls), String(m.connections),
                    String(m.decisionContacts), String(m.hearings), String(m.phoneAppointments), String(m.appointments),
                    String(m.meetings), String(m.orders), m.rate(m.connections, m.calls), m.rate(m.phoneAppointments, m.calls),
                    m.rate(m.orders, m.meetings), number(m.appointmentReward), number(m.meetingReward), number(m.orderReward),
                    number(m.reward), String(m.missingPrices)]
        }
    }
    static func filtered(_ activities: [SalesActivity], interval: DateInterval?) -> [SalesActivity] {
        let activities = activities.filter(\.isEffective)
        guard let interval else { return activities }
        return activities.filter { $0.date >= interval.start && $0.date < interval.end }
    }
}
