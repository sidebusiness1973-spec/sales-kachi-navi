import SwiftUI
import SwiftData

@main
struct SalesKachiNaviApp: App {
    @State private var storeKitManager = StoreKitManager()
    private let container: ModelContainer?
    private let startupError: String?
    init() {
        do {
            let schema = Schema([
                Item.self,
                Customer.self,
                SalesActivity.self,
                SalesPerson.self
            ])
            #if DEBUG
            let isScreenshotSession = ProcessInfo.processInfo.arguments.contains("--store-screenshots")
            #else
            let isScreenshotSession = false
            #endif
            let config = ModelConfiguration("SalesKachiNavi-v1", schema: schema, isStoredInMemoryOnly: isScreenshotSession, cloudKitDatabase: .none)
            let createdContainer = try ModelContainer(for: schema, configurations: [config])
            #if DEBUG
            if isScreenshotSession {
                let context = createdContainer.mainContext
                for (index, company) in ["掲載例・青空商事", "掲載例・みなと企画", "掲載例・ひかり工房"].enumerated() {
                    let customer = Customer(company: company)
                    customer.industry = "サービス"
                    customer.stage = index == 0 ? "商談" : "ヒアリング"
                    customer.needs = "業務の進め方を見直したい"
                    customer.followUp = Date().addingTimeInterval(86400)
                    customer.followUpNote = "提案内容を確認する"
                    context.insert(customer)
                    for activityIndex in 0..<6 {
                        let activity = SalesActivity(customer: customer)
                        activity.date = Date().addingTimeInterval(-Double(activityIndex * 900))
                        activity.kind = activityIndex == 5 ? "商談" : "電話"
                        activity.connected = activityIndex % 2 == 0
                        activity.hearing = activityIndex == 2
                        activity.appointment = activityIndex == 4
                        activity.note = "掲載用のサンプル記録"
                        context.insert(activity)
                    }
                }
                try context.save()
            }
            #endif
            container = createdContainer
            startupError = nil
        } catch {
            container = nil
            startupError = error.localizedDescription
        }
    }
    var body: some Scene {
        WindowGroup {
            if let container {
                ContentView()
                    .modelContainer(container)
                    .environment(storeKitManager)
                    .task {
                        await storeKitManager.start()
                    }
            } else {
                VStack(spacing: 20) {
                    Image(systemName: "externaldrive.badge.exclamationmark").font(.largeTitle)
                    Text("保存データを開けませんでした").font(.title2)
                    Text("データは削除していません。アプリを再起動してください。改善しない場合は、次の内容を開発者にお知らせください。")
                    Text(startupError ?? "不明なエラー").font(.caption).textSelection(.enabled)
                }.padding(32)
            }
        }
    }
}
