import SwiftUI
import SwiftData

struct SalesPeopleView: View {
    @Environment(StoreKitManager.self) private var store
    @Query(sort: \SalesPerson.createdAt) private var people: [SalesPerson]
    @State private var search = ""
    @State private var includeInactive = false
    @State private var adding = false
    @State private var editing: SalesPerson?
    @State private var showProRequired = false
    @State private var showPro = false

    private var visiblePeople: [SalesPerson] {
        people.filter { person in
            (includeInactive || person.isActive) &&
            (search.isEmpty || [person.name, person.department, person.email].contains { $0.localizedStandardContains(search) })
        }
    }
    var body: some View {
        List {
            Section {
                Toggle("無効の担当者も表示", isOn: $includeInactive)
                Text("在籍中 \(people.filter(\.isActive).count)名 ／ 全\(people.count)名")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("担当者") {
                ForEach(visiblePeople) { person in
                    Button { editing = person } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(person.name).font(.headline)
                                if !person.isActive { Text("無効").font(.caption).foregroundStyle(.secondary) }
                            }
                            if !person.department.isEmpty { Text(person.department).font(.subheadline) }
                            VStack(alignment: .leading, spacing: 3) {
                                ReadableValue("アポ単価", value: yen(person.appointmentUnitPrice))
                                ReadableValue("商談単価", value: yen(person.meetingUnitPrice))
                                ReadableValue("受注単価", value: yen(person.orderUnitPrice))
                            }
                                .font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 4)
                    }.buttonStyle(.plain)
                }
                if visiblePeople.isEmpty {
                    ContentUnavailableView("担当者がいません", systemImage: "person.2", description: Text("右上の追加ボタンから登録できます。検索・表示条件も確認してください。"))
                }
            }
            Section {
                Text("退職・休職した担当者は、編集画面で在籍をオフにすると記録を残せます。成果単価は1件あたりの円額です。担当者別集計で実績と成果金額を確認できます。単価を変更しても保存済みの活動の成果金額は変わりません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("担当者管理")
        .searchable(text: $search, prompt: "氏名・部署・メールで検索")
        .toolbar {
            Button("追加", systemImage: "plus") {
                if store.isPro || people.isEmpty {
                    adding = true
                } else {
                    showProRequired = true
                }
            }
        }
        .sheet(isPresented: $adding) { SalesPersonEditor(person: nil) }
        .sheet(item: $editing) { SalesPersonEditor(person: $0) }
        .sheet(isPresented: $showPro) {
            NavigationStack {
                PersonalProView()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("閉じる") { showPro = false }
                        }
                    }
            }
        }
        .alert("この機能はPersonal Proで利用できます", isPresented: $showProRequired) {
            Button("Personal Proを見る") { showPro = true }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("Freeプランでは担当者を1名まで登録できます。既存の担当者と過去データは削除されません。")
        }
    }
    private func yen(_ value: Double) -> String { value.formatted(.currency(code: "JPY")) }
}

struct SalesPersonEditor: View {
    @Environment(StoreKitManager.self) private var store
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    let person: SalesPerson?
    @State private var name: String
    @State private var department: String
    @State private var role: String
    @State private var email: String
    @State private var isActive: Bool
    @State private var appointment: String
    @State private var meeting: String
    @State private var order: String
    @State private var errorMessage: String?

    init(person: SalesPerson?) {
        self.person = person
        _name = State(initialValue: person?.name ?? "")
        _department = State(initialValue: person?.department ?? "")
        _role = State(initialValue: person?.role ?? "")
        _email = State(initialValue: person?.email ?? "")
        _isActive = State(initialValue: person?.isActive ?? true)
        _appointment = State(initialValue: String(person?.appointmentUnitPrice ?? 0))
        _meeting = State(initialValue: String(person?.meetingUnitPrice ?? 0))
        _order = State(initialValue: String(person?.orderUnitPrice ?? 0))
    }
    private func price(_ text: String) -> Double? {
        let normalized = text.applyingTransform(.fullwidthToHalfwidth, reverse: false) ?? text
        guard let value = Double(normalized.trimmingCharacters(in: .whitespacesAndNewlines)), value.isFinite, value >= 0, value <= 1_000_000_000 else { return nil }
        return value
    }
    private var valid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        [appointment, meeting, order].allSatisfy { price($0) != nil }
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("基本情報") {
                    TextField("氏名（必須）", text: $name)
                    TextField("部署", text: $department)
                    TextField("役職", text: $role)
                    TextField("メール", text: $email)
                    Toggle("在籍・有効", isOn: $isActive)
                }
                Section("成果単価（円／件）") {
                    TextField("アポ", text: $appointment)
                        .disabled(!store.isPro)
                    TextField("商談", text: $meeting)
                        .disabled(!store.isPro)
                    TextField("受注", text: $order)
                        .disabled(!store.isPro)
                    Text(store.isPro
                         ? "単価は0〜10億の数値で入力してください（カンマ不要）。支払いがない項目は0にします。"
                         : "成果単価の設定はPersonal Proで利用できます。保存済みの単価は変更・削除されません。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }.formStyle(.grouped)
            .navigationTitle(person == nil ? "担当者を追加" : "担当者を編集")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存", action: save).disabled(!valid) }
            }
            .alert("保存できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("閉じる", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
        }
        #if os(macOS)
        .frame(minWidth: 480, minHeight: 520)
        #endif
    }
    private func save() {
        guard valid, let a = price(appointment), let m = price(meeting), let o = price(order) else { return }
        let target = person ?? SalesPerson()
        let previous = (target.name, target.department, target.role, target.email, target.isActive,
                        target.appointmentUnitPrice, target.meetingUnitPrice, target.orderUnitPrice)
        if person == nil { context.insert(target) }
        target.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        target.department = department.trimmingCharacters(in: .whitespacesAndNewlines)
        target.role = role.trimmingCharacters(in: .whitespacesAndNewlines)
        target.email = email.trimmingCharacters(in: .whitespacesAndNewlines)
        target.isActive = isActive
        if store.isPro {
            target.appointmentUnitPrice = a
            target.meetingUnitPrice = m
            target.orderUnitPrice = o
        }
        do { try context.save(); dismiss() }
        catch {
            if person == nil { context.delete(target) }
            else {
                (target.name, target.department, target.role, target.email, target.isActive,
                 target.appointmentUnitPrice, target.meetingUnitPrice, target.orderUnitPrice) = previous
            }
            errorMessage = error.localizedDescription
        }
    }
}
