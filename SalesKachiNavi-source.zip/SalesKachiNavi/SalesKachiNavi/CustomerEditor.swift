import SwiftUI
import SwiftData

struct CustomerDraft {
    var company = "", contact = "", department = "", role = "", phone = "", email = ""
    var industry = "", size = "", region = "", stage = "見込み客", temperature = "未判定"
    var needs = "", currentSolution = "", budget = "", authority = "", timing = ""
    var competitors = "", users = "", motivation = "", blockers = "", qualification = "", notes = ""
    var expectedAmount = "", orderAmount = ""
    var hasFollowUp = false, followUp = Date(), followUpNote = ""
    init(_ c: Customer?) {
        guard let c else { return }
        expectedAmount = c.expectedDealAmountYen.map { String($0) } ?? ""
        orderAmount = c.orderAmountYen.map { String($0) } ?? ""
        company=c.company; contact=c.contact; department=c.department; role=c.role
        phone=c.phone; email=c.email; industry=c.industry; size=c.size; region=c.region
        stage=c.stage; temperature=c.temperature; needs=c.needs; currentSolution=c.currentSolution
        budget=c.budget; authority=c.authority; timing=c.timing; competitors=c.competitors
        users=c.users; motivation=c.motivation; blockers=c.blockers; qualification=c.qualification; notes=c.notes
        hasFollowUp=c.followUp != nil; followUp=c.followUp ?? Date(); followUpNote=c.followUpNote
    }
    func apply(to c: Customer) {
        c.expectedDealAmountYen = DealMoney.parse(expectedAmount)
        c.orderAmountYen = DealMoney.parse(orderAmount)
        c.company=company.trimmingCharacters(in: .whitespacesAndNewlines)
        c.contact=contact; c.department=department; c.role=role; c.phone=phone; c.email=email
        c.industry=industry; c.size=size; c.region=region; c.stage=stage; c.temperature=temperature
        c.needs=needs; c.currentSolution=currentSolution; c.budget=budget; c.authority=authority
        c.timing=timing; c.competitors=competitors; c.users=users; c.motivation=motivation
        c.blockers=blockers; c.qualification=qualification; c.notes=notes
        c.followUp=hasFollowUp ? followUp : nil; c.followUpNote=followUpNote
    }
}
struct CustomerEditor: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    let customer: Customer?
    @State private var draft: CustomerDraft
    @State private var errorMessage: String?
    init(customer: Customer? = nil) {
        self.customer = customer
        _draft = State(initialValue: CustomerDraft(customer))
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("基本情報（会社名は必須）") {
                    TextField("会社名", text: $draft.company)
                    TextField("担当者名", text: $draft.contact)
                    TextField("部署", text: $draft.department)
                    TextField("役職", text: $draft.role)
                    TextField("電話番号", text: $draft.phone)
                    TextField("メール", text: $draft.email)
                    TextField("業種", text: $draft.industry)
                    TextField("会社規模", text: $draft.size)
                    TextField("地域", text: $draft.region)
                }
                Section("案件・スクリーニング") {
                    Picker("進捗", selection: $draft.stage) { ForEach(SalesOptions.stages, id: \.self) { Text($0) } }
                    Text("進捗の変更だけでは成果金額は発生しません。アポ・商談・受注の成果は、顧客詳細の「営業活動を記録」から保存してください。")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("見込み度", selection: $draft.temperature) { ForEach(SalesOptions.temperatures, id: \.self) { Text($0) } }
                    TextField("判定理由・対象条件", text: $draft.qualification, axis: .vertical)
                }
                Section("会社・案件の金額（円）") {
                    TextField("案件見込額（任意）", text: $draft.expectedAmount)
                    TextField("受注額（任意）", text: $draft.orderAmount)
                    Text("空欄は未設定、0は0円として保存します。0〜1兆円の整数で入力してください。担当者の成果単価とは別の金額で、進捗を変えても自動入力されません。")
                        .font(.caption).foregroundStyle(.secondary)
                    if !DealMoney.valid(draft.expectedAmount) || !DealMoney.valid(draft.orderAmount) {
                        Text("金額は0〜1兆円の整数で入力してください。").font(.caption).foregroundStyle(.red)
                    }
                }
                Section("状況ヒアリング") {
                    TextField("現在の課題・困りごと", text: $draft.needs, axis: .vertical)
                    TextField("現在の製品・運用方法", text: $draft.currentSolution, axis: .vertical)
                    TextField("予算・予算化の状況", text: $draft.budget)
                    TextField("決裁者・承認の流れ", text: $draft.authority, axis: .vertical)
                    TextField("導入時期・期限", text: $draft.timing)
                    TextField("競合・比較先", text: $draft.competitors)
                    TextField("利用人数・対象部署", text: $draft.users)
                    TextField("導入したい理由・期待効果", text: $draft.motivation, axis: .vertical)
                    TextField("懸念点・導入しない理由", text: $draft.blockers, axis: .vertical)
                }
                Section("次回の行動") {
                    Toggle("再連絡の予定を設定", isOn: $draft.hasFollowUp)
                    if draft.hasFollowUp {
                        DatePicker("日時", selection: $draft.followUp)
                        TextField("連絡の目的・約束した内容", text: $draft.followUpNote, axis: .vertical)
                    }
                    TextField("その他のメモ", text: $draft.notes, axis: .vertical)
                }
            }.formStyle(.grouped)
            .navigationTitle(customer == nil ? "顧客を登録" : "顧客を編集")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存", action: save).disabled(draft.company.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !DealMoney.valid(draft.expectedAmount) || !DealMoney.valid(draft.orderAmount))
                }
            }
            .alert("保存できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("閉じる", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
        }
        #if os(macOS)
        .frame(minWidth: 560, minHeight: 650)
        #endif
    }
    private func save() {
        guard DealMoney.valid(draft.expectedAmount), DealMoney.valid(draft.orderAmount) else {
            errorMessage = "金額は0〜1兆円の整数で入力してください。"; return
        }
        let c = customer ?? Customer()
        if customer == nil { context.insert(c) }
        draft.apply(to: c)
        do { try context.save(); dismiss() }
        catch { context.rollback(); errorMessage=error.localizedDescription }
    }
}
