import Foundation
import SwiftData

enum SalesOptions {
    static let stages = ["見込み客", "接触済", "ヒアリング", "有望", "アポ", "商談", "提案", "受注", "失注"]
    static let temperatures = ["未判定", "HOT", "WARM", "COLD", "対象外"]
    static let outcomes = ["不在", "受付NG", "担当者不在", "担当者接続", "興味なし", "再架電", "資料送付", "ヒアリング実施", "アポ獲得"]
    static let kinds = ["電話", "メール", "アポ", "商談", "提案", "受注", "失注", "メモ"]
}

@Model final class Customer {
    var id: UUID = UUID()
    var createdAt: Date = Date()
    var company: String = ""
    var contact: String = ""
    var department: String = ""
    var role: String = ""
    var phone: String = ""
    var email: String = ""
    var industry: String = ""
    var size: String = ""
    var region: String = ""
    var expectedDealAmountYen: Int64?
    var orderAmountYen: Int64?
    var stage: String = "見込み客"
    var temperature: String = "未判定"
    var needs: String = ""
    var currentSolution: String = ""
    var budget: String = ""
    var authority: String = ""
    var timing: String = ""
    var competitors: String = ""
    var users: String = ""
    var motivation: String = ""
    var blockers: String = ""
    var qualification: String = ""
    var notes: String = ""
    var followUp: Date?
    var followUpNote: String = ""
    @Relationship(deleteRule: .cascade, inverse: \SalesActivity.customer)
    var activities: [SalesActivity] = []
    init(company: String = "") { self.company = company }
}

@Model final class SalesActivity {
    var id: UUID = UUID()
    var date: Date = Date()
    var kind: String = "電話"
    var outcome: String = "不在"
    var respondent: String = ""
    // Optional additions preserve old records; nil means no historical assignment or price.
    var salesPersonID: UUID?
    var salesPersonNameSnapshot: String?
    var appointmentPriceSnapshot: Double?
    var meetingPriceSnapshot: Double?
    var orderPriceSnapshot: Double?
    var pricesCapturedAt: Date?
    // nil state is an effective pre-audit record. Original activity contents remain intact.
    var recordState: String?
    var invalidatedAt: Date?
    var correctionRecordedAt: Date?
    var correctionReason: String?
    var invalidationReason: String?
    var replacesActivityID: UUID?
    var replacedByActivityID: UUID?
    var duplicateConfirmedAt: Date?
    var duplicateCandidateIDs: String?
    // Restoration adds a new effective record; the cancelled record stays unchanged.
    var restoresActivityID: UUID?
    var restoredByActivityID: UUID?
    var restoredAt: Date?
    var restorationReason: String?
    var connected: Bool = false
    var decisionContact: Bool = false
    var hearing: Bool = false
    var appointment: Bool = false
    var note: String = ""
    var customer: Customer?
    init(customer: Customer? = nil) { self.customer = customer }
}
