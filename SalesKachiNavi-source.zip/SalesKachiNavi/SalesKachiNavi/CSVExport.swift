import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct CSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    var text: String
    init(text: String = "") { self.text=text }
    init(configuration: ReadConfiguration) throws {
        text=String(data: configuration.file.regularFileContents ?? Data(), encoding: .utf8) ?? ""
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(("\u{FEFF}" + text).utf8))
    }
}
enum CSVExport {
    // Quotes preserve newlines and commas; prefix spreadsheet formulas to prevent execution.
    nonisolated static func cell(_ value: String) -> String {
        let trimmed=value.trimmingCharacters(in: .whitespacesAndNewlines)
        let safe = ["=", "+", "-", "@"].contains(String(trimmed.prefix(1))) || value.hasPrefix("\t") || value.hasPrefix("\r") ? "'" + value : value
        return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
    nonisolated static func table(_ rows: [[String]]) -> String { rows.map { $0.map(cell).joined(separator: ",") }.joined(separator: "\r\n") }
    static func customerRows(_ customers: [Customer]) -> [[String]] {
        let header=["ID", "会社名", "担当者", "部署", "役職", "電話", "メール", "業種", "規模", "地域", "進捗", "見込み度", "課題", "現状", "予算", "決裁者", "導入時期", "競合", "利用人数", "期待効果", "懸念", "判定理由", "再連絡日時", "連絡目的", "メモ", "会社・案件見込額（円）", "会社・案件受注額（円）"]
        return [header] + customers.map { c in
            [c.id.uuidString, c.company, c.contact, c.department, c.role, c.phone, c.email, c.industry, c.size, c.region, c.stage, c.temperature, c.needs, c.currentSolution, c.budget, c.authority, c.timing, c.competitors, c.users, c.motivation, c.blockers, c.qualification, c.followUp?.ISO8601Format() ?? "", c.followUpNote, c.notes, c.expectedDealAmountYen.map { String($0) } ?? "", c.orderAmountYen.map { String($0) } ?? ""]
        }
    }
    static func activityRows(_ activities: [SalesActivity]) -> [[String]] {
        let header = ["ID", "顧客ID", "会社名", "日時", "種別", "結果", "電話相手", "接続", "担当者接続", "ヒアリング", "アポ獲得", "メモ", "営業担当者ID", "営業担当者名（記録時）", "アポ単価（記録時）", "商談単価（記録時）", "受注単価（記録時）", "単価記録日時", "担当者成果金額（記録値・取消含む・円）", "単価記録状態", "有効／取り消し状態", "集計対象", "訂正版保存日時", "訂正理由", "取り消し／旧版無効化日時", "取り消し／旧版無効化理由", "訂正元ID", "訂正版ID", "重複候補確認日時", "重複候補ID", "担当者成果金額（有効集計対象・円）", "復元元ID", "復元先ID", "この記録の復元日時", "この記録の復元理由"]
        let rows: [[String]] = activities.map { a in
            var row: [String] = [a.id.uuidString, a.customer?.id.uuidString ?? "", a.customer?.company ?? "", a.date.ISO8601Format(), a.kind, a.outcome, a.respondent]
            row += [a.connected ? "1" : "0", a.decisionContact ? "1" : "0", a.hearing ? "1" : "0", a.appointment ? "1" : "0", a.note]
            row += [a.salesPersonID?.uuidString ?? "", a.salesPersonNameSnapshot ?? ""]
            row += [a.appointmentPriceSnapshot.map { String($0) } ?? "", a.meetingPriceSnapshot.map { String($0) } ?? "", a.orderPriceSnapshot.map { String($0) } ?? "", a.pricesCapturedAt?.ISO8601Format() ?? ""]
            row += [a.hasPriceSnapshot ? SalesKPI.number(a.reward) : "", a.hasPriceSnapshot ? "記録時単価" : "単価記録なし"]
            row += [a.statusLabel, a.isEffective ? "1" : "0", a.correctionRecordedAt?.ISO8601Format() ?? "", a.correctionReason ?? "", a.invalidatedAt?.ISO8601Format() ?? "", a.invalidationReason ?? ""]
            row += [a.replacesActivityID?.uuidString ?? "", a.replacedByActivityID?.uuidString ?? "", a.duplicateConfirmedAt?.ISO8601Format() ?? "", a.duplicateCandidateIDs ?? ""]
            row.append(!a.isEffective ? "0" : (a.hasPriceSnapshot ? SalesKPI.number(a.reward) : ""))
            row += [a.restoresActivityID?.uuidString ?? "", a.restoredByActivityID?.uuidString ?? "", a.restoredAt?.ISO8601Format() ?? "", a.restorationReason ?? ""]
            return row
        }
        return [header] + rows
    }
    static func salesPersonRows(_ people: [SalesPerson]) -> [[String]] {
        [["ID", "氏名", "部署", "役職", "メール", "在籍・有効", "アポ単価（円）", "商談単価（円）", "受注単価（円）"]] + people.map { p in
            [p.id.uuidString, p.name, p.department, p.role, p.email, p.isActive ? "1" : "0", String(p.appointmentUnitPrice), String(p.meetingUnitPrice), String(p.orderUnitPrice)]
        }
    }
    static func basicCustomerRows(_ customers: [Customer]) -> [[String]] {
        [["会社名", "担当者", "電話", "メール", "進捗", "見込み度", "再連絡日時", "メモ"]] + customers.map { customer in
            [customer.company, customer.contact, customer.phone, customer.email, customer.stage,
             customer.temperature, customer.followUp?.ISO8601Format() ?? "", customer.notes]
        }
    }
    static func basicActivityRows(_ activities: [SalesActivity]) -> [[String]] {
        [["会社名", "日時", "種別", "結果", "対応者", "メモ"]] + activities.map { activity in
            [activity.customer?.company ?? "", activity.date.ISO8601Format(), activity.kind,
             activity.outcome, activity.respondent, activity.note]
        }
    }
    static func customers(_ items: [Customer]) -> String { table(customerRows(items)) }
    static func activities(_ items: [SalesActivity]) -> String { table(activityRows(items)) }
}
