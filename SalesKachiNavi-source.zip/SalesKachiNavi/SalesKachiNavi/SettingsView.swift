import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct SettingsView: View {
    @Environment(StoreKitManager.self) private var store
    @Query private var customers: [Customer]
    @Query private var activities: [SalesActivity]
    @Query(sort: \SalesPerson.createdAt) private var people: [SalesPerson]
    @State private var document = CSVDocument()
    @State private var exporting = false
    @State private var fileName = "customers"
    @State private var excel = ExcelDocument()
    @State private var exportingExcel = false
    @State private var exportError: String?
    @State private var showProRequired = false
    @State private var showPro = false
    var body: some View {
        Form {
            Section("基本CSV（Free）") {
                Button("顧客・案件を基本CSV出力") {
                    exportCSV(CSVExport.basicCustomerRows(customers), fileName: "customers-basic")
                }
                Button("営業活動を基本CSV出力") {
                    exportCSV(CSVExport.basicActivityRows(activities), fileName: "activities-basic")
                }
                Text("基本CSVには日常的な管理項目を出力します。保存済みデータ自体は変更しません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("詳細出力（Personal Pro）") {
                proButton("顧客・ヒアリングを詳細CSV出力") {
                    exportCSV(CSVExport.customerRows(customers), fileName: "customers-detail")
                }
                proButton("営業活動・監査履歴を詳細CSV出力") {
                    exportCSV(CSVExport.activityRows(activities), fileName: "activities-audit")
                }
                proButton("担当者・成果単価を詳細CSV出力") {
                    exportCSV(CSVExport.salesPersonRows(people), fileName: "sales-people")
                }
                proButton("担当者別KPI・成果金額をCSV出力（全期間）") {
                    exportCSV(SalesKPI.rows(activities, people: people, period: "全期間"), fileName: "team-kpi-all")
                }
                Text("期間を絞った集計と出力は「担当者別集計」で行えます。")
                    .font(.caption).foregroundStyle(.secondary)
                proButton("Excelブックで一括出力（.xlsx）") {
                    excel=ExcelDocument(data: ExcelExport.workbook(sheets: [("顧客", CSVExport.customerRows(customers)), ("営業活動", CSVExport.activityRows(activities)), ("担当者", CSVExport.salesPersonRows(people)), ("担当者別集計", SalesKPI.rows(activities, people: people, period: "全期間"))])); exportingExcel=true
                }
                Text("ExcelやGoogleスプレッドシートにCSVファイルを読み込めます。電話番号は文字列として読み込むと、先頭の0を保てます。Excelブックでは電話番号も文字列として保存します。Googleとの直接同期は未対応です。").font(.caption).foregroundStyle(.secondary)
            }
            Section("現在のバージョン") {
                LabeledContent("プラン", value: store.isPro ? "Personal Pro" : "Free")
                LabeledContent("保存先", value: "この端末")
                Button(store.isPro ? "Personal Proの詳細" : "Personal Proを見る") { showPro = true }
                Text("顧客・営業活動は端末内に保存されます。iPhoneとMacのデータは、現時点では自動同期されません。")
                Text("プランが変わっても、既存の担当者・顧客・営業活動や監査履歴は削除されません。")
            }
            Section("データの取り扱い") {
                Text("入力した顧客情報、連絡先、営業記録はこの端末内に保存します。アプリから開発者のサーバーへの送信、広告配信、アクセス解析は行いません。")
                Text("CSV出力を選ぶと、選択した保存先にデータを書き出します。共有先やファイルの管理にはご注意ください。活動は訂正・取り消しで履歴を残せます。活動履歴がない顧客は顧客詳細から削除できます。端末のバックアップ設定によっては、OSのバックアップに含まれる場合があります。")
            }
        }.formStyle(.grouped).navigationTitle("設定・出力")
        .fileExporter(isPresented: $exporting, document: document, contentType: .commaSeparatedText, defaultFilename: fileName) { result in
            if case .failure(let error) = result { exportError=error.localizedDescription }
        }
        .fileExporter(isPresented: $exportingExcel, document: excel, contentType: ExcelDocument.readableContentTypes[0], defaultFilename: "SalesKachiNavi") { result in
            if case .failure(let error) = result { exportError=error.localizedDescription }
        }
        .alert("出力できませんでした", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError=nil } })) {
            Button("閉じる", role: .cancel) {}
        } message: { Text(exportError ?? "") }
        .alert("この機能はPersonal Proで利用できます", isPresented: $showProRequired) {
            Button("Personal Proを見る") { showPro = true }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("詳細CSV、Excel一括出力、監査履歴の詳細出力はPersonal Proで利用できます。")
        }
        .sheet(isPresented: $showPro) {
            NavigationStack {
                PersonalProView()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("閉じる") { showPro = false }
                        }
                    }
            }
        }
    }

    @ViewBuilder
    private func proButton(_ title: LocalizedStringKey, action: @escaping () -> Void) -> some View {
        Button {
            if store.isPro { action() } else { showProRequired = true }
        } label: {
            HStack {
                Text(title)
                Spacer()
                if !store.isPro {
                    Image(systemName: "lock.fill").foregroundStyle(.secondary)
                }
            }
        }
    }

    private func exportCSV(_ rows: [[String]], fileName: String) {
        document = CSVDocument(text: CSVExport.table(rows))
        self.fileName = fileName
        exporting = true
    }
}
