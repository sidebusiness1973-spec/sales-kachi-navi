import Foundation

/// Company deal amounts are whole yen, independent of salesperson compensation.
enum DealMoney {
    static let maximum: Int64 = 1_000_000_000_000
    static func parse(_ text: String) -> Int64? {
        let normalized = (text.applyingTransform(.fullwidthToHalfwidth, reverse: false) ?? text)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        // Accept plain digits or properly grouped thousands; reject signs, decimals and exponents.
        guard normalized.range(of: #"^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)$"#, options: .regularExpression) != nil,
              let value = Int64(normalized.replacingOccurrences(of: ",", with: "")), value <= maximum else { return nil }
        return value
    }
    static func valid(_ text: String) -> Bool {
        text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || parse(text) != nil
    }
    static func display(_ value: Int64?) -> String {
        guard let value else { return "未設定" }
        return value.formatted(.number.locale(Locale(identifier: "ja_JP"))) + "円"
    }
    static func total(_ values: [Int64?]) -> String {
        let total = values.compactMap { $0 }.reduce(Decimal(0)) { $0 + Decimal($1) }
        return total.formatted(.number.locale(Locale(identifier: "ja_JP"))) + "円"
    }
    static func rows(_ customers: [Customer]) -> [[String]] {
        [["区分", "会社・案件金額合計（円）", "金額設定件数", "金額未設定件数", "対象"],
         ["案件見込額", SalesKPI.number(customers.compactMap(\.expectedDealAmountYen).reduce(Decimal(0)) { $0 + Decimal($1) }), String(customers.filter { $0.expectedDealAmountYen != nil }.count), String(customers.filter { $0.expectedDealAmountYen == nil }.count), "全顧客の現在値・活動期間とは無関係"],
         ["受注額", SalesKPI.number(customers.compactMap(\.orderAmountYen).reduce(Decimal(0)) { $0 + Decimal($1) }), String(customers.filter { $0.orderAmountYen != nil }.count), String(customers.filter { $0.orderAmountYen == nil }.count), "全顧客の現在値・担当者成果金額とは別"]]
    }
}
