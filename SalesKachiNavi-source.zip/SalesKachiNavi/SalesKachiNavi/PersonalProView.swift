import StoreKit
import SwiftUI

enum LegalLinks {
    static let termsOfUse = URL(string: "https://note.com/hiroamasong/n/nc7c8a653fe96")
    static let privacyPolicy = URL(string: "https://note.com/hiroamasong/n/n5ce50e2b2c7a")
}

struct PersonalProView: View {
    @Environment(StoreKitManager.self) private var store
    @Environment(\.openURL) private var openURL
    @State private var legalMessage: String?
    @State private var isRestoring = false
    @State private var purchasingProductID: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                ProHeroSection(isPro: store.isPro)
                ProFeatureSection()
                ProPlansSection(
                    monthlyProduct: store.product(for: StoreProductID.monthly),
                    yearlyProduct: store.product(for: StoreProductID.yearly),
                    loadingState: store.loadingState,
                    isPro: store.isPro,
                    purchasingProductID: purchasingProductID,
                    onPurchase: purchase,
                    onRetry: { Task { await store.loadProducts() } }
                )
                ProFooterSection(
                    isPro: store.isPro,
                    isRestoring: isRestoring,
                    onRestore: restore,
                    onOpenTerms: { openLegalLink(LegalLinks.termsOfUse, name: "利用規約") },
                    onOpenPrivacy: { openLegalLink(LegalLinks.privacyPolicy, name: "プライバシーポリシー") }
                )
            }
            .frame(maxWidth: 720, alignment: .leading)
            .padding()
        }
        .navigationTitle("Personal Pro")
        .alert(
            "Personal Pro",
            isPresented: Binding(
                get: { store.purchaseOutcome != nil },
                set: { if !$0 { store.clearPurchaseOutcome() } }
            )
        ) {
            Button("閉じる", role: .cancel) { store.clearPurchaseOutcome() }
        } message: {
            Text(purchaseMessage)
        }
        .alert(
            "リンク設定待ち",
            isPresented: Binding(
                get: { legalMessage != nil },
                set: { if !$0 { legalMessage = nil } }
            )
        ) {
            Button("閉じる", role: .cancel) {}
        } message: {
            Text(legalMessage ?? "")
        }
    }

    private var purchaseMessage: String {
        switch store.purchaseOutcome {
        case .purchased:
            "購入状態を確認しました。Personal Proをご利用いただけます。"
        case .pending:
            "購入は保留中です。承認または決済が完了すると自動的に反映されます。"
        case .cancelled:
            "購入はキャンセルされました。"
        case .failed(let message):
            message
        case nil:
            ""
        }
    }

    private func purchase(_ productID: String) {
        guard !store.isPro else { return }
        purchasingProductID = productID
        Task {
            await store.purchase(productID: productID)
            purchasingProductID = nil
        }
    }

    private func restore() {
        isRestoring = true
        Task {
            await store.restorePurchases()
            isRestoring = false
        }
    }

    private func openLegalLink(_ url: URL?, name: String) {
        guard let url else {
            legalMessage = "\(name)の公開URLはまだ設定されていません。"
            return
        }
        openURL(url)
    }
}

private struct ProHeroSection: View {
    let isPro: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("営業マン勝ちナビ Personal Pro", systemImage: "chart.line.uptrend.xyaxis")
                .font(.title.bold())
                .foregroundStyle(.teal)
            Text("「営業記録を残す」から\n「営業数字を管理する」へ。")
                .font(.title2.weight(.semibold))
            Label(
                isPro ? "Personal Proを利用中" : "現在はFreeプラン",
                systemImage: isPro ? "checkmark.seal.fill" : "person.crop.circle"
            )
            .foregroundStyle(isPro ? .green : .secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct ProFeatureSection: View {
    private let features = [
        "複数担当者管理",
        "担当者別詳細KPI",
        "成果単価／成果報酬管理",
        "詳細分析",
        "Excel一括出力",
        "詳細CSV",
        "監査履歴の詳細出力"
    ]

    var body: some View {
        GroupBox("Proで利用できる主な機能") {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(features, id: \.self) { feature in
                    Label(feature, systemImage: "checkmark.circle.fill")
                        .foregroundStyle(.primary, .teal)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 6)
        }
    }
}

private struct ProPlansSection: View {
    let monthlyProduct: Product?
    let yearlyProduct: Product?
    let loadingState: StoreLoadingState
    let isPro: Bool
    let purchasingProductID: String?
    let onPurchase: (String) -> Void
    let onRetry: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            ProPlanRow(
                title: "月額プラン",
                product: monthlyProduct,
                isPro: isPro,
                isPurchasing: purchasingProductID == StoreProductID.monthly,
                onPurchase: { onPurchase(StoreProductID.monthly) }
            )
            ProPlanRow(
                title: "年額プラン",
                product: yearlyProduct,
                isPro: isPro,
                isPurchasing: purchasingProductID == StoreProductID.yearly,
                onPurchase: { onPurchase(StoreProductID.yearly) }
            )

            switch loadingState {
            case .idle, .loading:
                HStack {
                    ProgressView()
                    Text("App Storeからプランを読み込んでいます…")
                        .foregroundStyle(.secondary)
                }
            case .failed(let message):
                VStack(spacing: 8) {
                    Text(message)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                    Button("再読み込み", action: onRetry)
                }
            case .loaded:
                EmptyView()
            }
        }
    }
}

private struct ProPlanRow: View {
    let title: LocalizedStringResource
    let product: Product?
    let isPro: Bool
    let isPurchasing: Bool
    let onPurchase: () -> Void

    var body: some View {
        GroupBox {
            ViewThatFits {
                HStack(spacing: 16) {
                    planDescription
                    Spacer()
                    purchaseButton
                }
                VStack(alignment: .leading, spacing: 12) {
                    planDescription
                    purchaseButton
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var planDescription: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.headline)
            Text(product?.displayPrice ?? "価格を取得できません")
                .font(.title2.bold())
            if let period = product?.subscription?.subscriptionPeriod {
                Text(period.unit == .year ? "1年ごとの自動更新" : "1か月ごとの自動更新")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var purchaseButton: some View {
        Button(action: onPurchase) {
            if isPurchasing {
                ProgressView()
                    .controlSize(.small)
            } else {
                Text(isPro ? "購入済み" : "購入する")
            }
        }
        .buttonStyle(.borderedProminent)
        .disabled(product == nil || isPro || isPurchasing)
    }
}

private struct ProFooterSection: View {
    let isPro: Bool
    let isRestoring: Bool
    let onRestore: () -> Void
    let onOpenTerms: () -> Void
    let onOpenPrivacy: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Button(action: onRestore) {
                if isRestoring {
                    ProgressView()
                } else {
                    Text("購入を復元")
                }
            }
            .disabled(isRestoring)

            ViewThatFits {
                HStack {
                    Button("利用規約", action: onOpenTerms)
                    Button("プライバシーポリシー", action: onOpenPrivacy)
                }
                VStack(alignment: .leading) {
                    Button("利用規約", action: onOpenTerms)
                    Button("プライバシーポリシー", action: onOpenPrivacy)
                }
            }
            .buttonStyle(.borderless)

            Text("お支払いはApple IDに請求されます。サブスクリプションは、現在の期間終了の24時間以上前にキャンセルしない限り自動更新されます。購入後はApp Storeのアカウント設定から管理・解約できます。")
                .font(.caption)
                .foregroundStyle(.secondary)

            if isPro {
                Text("有効な購入情報はApp Storeで確認され、状態の変更はアプリの起動中にも反映されます。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
