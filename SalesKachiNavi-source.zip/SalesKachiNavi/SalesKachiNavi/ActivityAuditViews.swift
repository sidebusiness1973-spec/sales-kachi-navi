import SwiftUI
import SwiftData

struct ActivityHistoryRow: View {
    let activity: SalesActivity
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(activity.statusLabel).font(.caption.bold())
                .foregroundStyle(activity.isEffective ? Color.teal : Color.orange)
            Text(activity.kind == "電話" ? "電話 · \(activity.outcome)" : activity.kind).font(.headline)
            Text(activity.date, format: .dateTime.year().month().day().hour().minute()).font(.caption).foregroundStyle(.secondary)
            Text("営業担当者：\(activity.salesPersonNameSnapshot ?? "未割当（旧記録）")")
            Text(activity.hasPriceSnapshot ? "担当者成果金額（記録値）：\(SalesKPI.money(activity.reward))" : "単価記録なし")
                .font(.caption).foregroundStyle(.secondary)
            if !activity.respondent.isEmpty { Text("電話相手：\(activity.respondent)") }
            if !activity.note.isEmpty { Text(activity.note) }
            if let date = activity.correctionRecordedAt {
                Text("訂正版の保存：\(date.formatted())").font(.caption)
                Text("訂正理由：\(activity.correctionReason ?? "")").font(.caption)
            }
            if let date = activity.invalidatedAt {
                Text("集計対象外にした日時：\(date.formatted())").font(.caption)
                Text("理由：\(activity.invalidationReason ?? "")").font(.caption)
            }
            if let date = activity.restoredAt {
                Text("この記録を復元した日時：\(date.formatted())").font(.caption)
                Text("復元理由：\(activity.restorationReason ?? "")").font(.caption)
            }
            if let next = activity.customer?.activities.first(where: { $0.id == activity.restoredByActivityID }) {
                Text("この取り消しを復元した日時：\(next.restoredAt?.formatted() ?? "未記録")").font(.caption)
                Text("復元理由：\(next.restorationReason ?? "")").font(.caption)
            }
            if !activity.isEffective || activity.replacesActivityID != nil || activity.restoresActivityID != nil {
                DisclosureGroup("履歴の関連番号") {
                    Text("記録ID：\(activity.id.uuidString)")
                    if let id = activity.replacesActivityID { Text("訂正元ID：\(id.uuidString)") }
                    if let id = activity.replacedByActivityID { Text("訂正版ID：\(id.uuidString)") }
                    if let id = activity.restoresActivityID { Text("復元元ID：\(id.uuidString)") }
                    if let id = activity.restoredByActivityID { Text("復元先ID：\(id.uuidString)") }
                }.font(.caption).textSelection(.enabled)
            }
            if let date = activity.duplicateConfirmedAt {
                Text("重複候補を確認し別成果として保存：\(date.formatted())").font(.caption)
            }
        }.padding(.vertical, 5)
    }
}

struct DuplicateActivityReview: View {
    @Environment(\.dismiss) private var dismiss
    let candidates: [SalesActivity]
    let confirm: () -> Void
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("同じ成果がすでに登録されている可能性があります。")
                    Text("同じ顧客・営業担当者・成果種別の前後30分以内にある、有効な活動です。本当に別の成果か、以下の記録を確認してください。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ForEach(candidates) { ActivityHistoryRow(activity: $0) }
                Section {
                    Button(action: confirm) { Text("別の成果として保存する").frame(maxWidth: .infinity, minHeight: 44) }.buttonStyle(.borderedProminent)
                }
            }.navigationTitle("重複候補を確認")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("入力に戻る") { dismiss() } } }
        }
        #if os(macOS)
        .frame(minWidth: 520, minHeight: 460)
        #endif
    }
}

struct CancelActivityView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    let activity: SalesActivity
    @State private var reason = ""
    @State private var confirming = false
    @State private var saving = false
    @State private var errorMessage: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("取り消す記録") { ActivityHistoryRow(activity: activity) }
                Section("取り消し理由（必須）") {
                    TextField("理由", text: $reason, axis: .vertical).lineLimit(2...5)
                    Text("記録と単価は履歴に残り、KPI・成果金額・重複判定から除外されます。誤って取り消した場合は、活動履歴から理由を入力して復元できます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section {
                    Button(role: .destructive) { confirming = true } label: {
                        Text("内容を確認して取り消す").frame(maxWidth: .infinity, minHeight: 44)
                    }.buttonStyle(.bordered)
                        .disabled(saving || !activity.isEffective || reason.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.formStyle(.grouped).navigationTitle("活動の取り消し")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("戻る") { dismiss() } }
            }
            .confirmationDialog("この活動を集計対象から取り消しますか？", isPresented: $confirming, titleVisibility: .visible) {
                Button("理由を保存して取り消す", role: .destructive, action: cancelActivity)
            } message: { Text("履歴は残ります。\n理由：\(reason)") }
            .alert("保存できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("閉じる", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
        }
        #if os(macOS)
        .frame(minWidth: 520, minHeight: 500)
        #endif
    }
    private func cancelActivity() {
        let explanation = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !saving, activity.isEffective, !explanation.isEmpty else { return }
        saving = true
        let previous = (activity.recordState, activity.invalidatedAt, activity.invalidationReason)
        let autosave = context.autosaveEnabled
        context.autosaveEnabled = false
        defer { context.autosaveEnabled = autosave }
        do {
            try ActivityAudit.cancel(activity, reason: explanation)
            try context.save()
            dismiss()
        }
        catch {
            (activity.recordState, activity.invalidatedAt, activity.invalidationReason) = previous
            saving = false; errorMessage = error.localizedDescription
        }
    }
}
