import SwiftUI
import SwiftData

struct CustomersView: View {
    @Query(sort: \Customer.createdAt, order: .reverse) private var customers: [Customer]
    @State private var search = ""
    @State private var stage = "すべて"
    @State private var adding = false
    var filtered: [Customer] {
        customers.filter {
            (stage == "すべて" || $0.stage == stage) &&
            (search.isEmpty || [$0.company, $0.contact, $0.phone, $0.needs].joined(separator: " ").localizedStandardContains(search))
        }
    }
    var body: some View {
        List {
            Picker("進捗で絞り込み", selection: $stage) {
                Text("すべて").tag("すべて")
                ForEach(SalesOptions.stages, id: \.self) { Text($0).tag($0) }
            }
            ForEach(filtered) { c in
                NavigationLink { CustomerDetail(customer: c) } label: { CustomerRow(customer: c) }
            }
            if filtered.isEmpty {
                ContentUnavailableView(search.isEmpty ? "顧客を登録しましょう" : "該当する顧客がありません", systemImage: "person.2", description: Text("右上の＋から会社・担当者と営業状況を登録できます。"))
            }
        }
        .navigationTitle("顧客・案件（\(filtered.count)）")
        .searchable(text: $search, prompt: "会社・担当者・電話・課題")
        .toolbar { Button { adding = true } label: { Label("顧客を登録", systemImage: "plus") } }
        .sheet(isPresented: $adding) { CustomerEditor() }
    }
}
struct CustomerRow: View {
    let customer: Customer
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(customer.company).font(.headline)
            Text([customer.contact, customer.department].filter { !$0.isEmpty }.joined(separator: " · ")).font(.subheadline).foregroundStyle(.secondary)
            Text("案件見込額：\(DealMoney.display(customer.expectedDealAmountYen))")
                .font(.caption).foregroundStyle(.secondary)
            Text("受注額：\(DealMoney.display(customer.orderAmountYen))")
                .font(.caption).foregroundStyle(.secondary)
            HStack {
                Text(customer.stage).font(.caption).padding(.horizontal, 8).padding(.vertical, 3).background(.teal.opacity(0.12), in: Capsule())
                Text(customer.temperature).font(.caption).foregroundStyle(customer.temperature == "HOT" ? .orange : .secondary)

            }
            if let date = customer.followUp { Text("再連絡：\(date.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(date < Date() ? .orange : .secondary) }
        }.padding(.vertical, 5)
    }
}
struct CustomerDetail: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    let customer: Customer
    @State private var editing = false
    @State private var recording = false
    @State private var deleting = false
    @State private var correctingActivity: SalesActivity?
    @State private var cancellingActivity: SalesActivity?
    @State private var restoringActivity: SalesActivity?
    @State private var errorMessage: String?
    var body: some View {
        List {
            Section("顧客情報") {
                row("担当者", customer.contact); row("部署・役職", "\(customer.department) \(customer.role)")
                row("電話", customer.phone); row("メール", customer.email)
                row("業種", customer.industry); row("会社規模", customer.size); row("地域", customer.region)
                row("進捗", customer.stage); row("見込み度", customer.temperature); row("判定理由", customer.qualification)
            }
            Section("会社・案件の金額") {
                row("案件見込額", DealMoney.display(customer.expectedDealAmountYen))
                row("受注額", DealMoney.display(customer.orderAmountYen))
                Text("会社・案件の金額です。担当者の成果単価・成果金額とは別に管理します。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("次回の行動") {
                if let date = customer.followUp {
                    ReadableValue("再連絡", value: date.formatted(date: .abbreviated, time: .shortened))
                    row("目的", customer.followUpNote)
                    Button("予定を完了にする") {
                        customer.followUp=nil
                        do { try context.save() } catch { context.rollback(); errorMessage=error.localizedDescription }
                    }
                } else { Text("予定は未設定です。編集から登録できます。").foregroundStyle(.secondary) }
            }
            Section("ヒアリング") {
                row("課題", customer.needs); row("現状", customer.currentSolution); row("予算", customer.budget)
                row("決裁", customer.authority); row("時期", customer.timing); row("競合", customer.competitors)
                row("利用人数", customer.users); row("期待効果", customer.motivation); row("懸念", customer.blockers)
                row("メモ", customer.notes)
            }
            Section("活動履歴（\(customer.activities.count)）") {
                Button { recording=true } label: { Label("電話・営業活動を記録", systemImage: "plus.circle.fill") }
                ForEach(customer.activities.sorted { $0.date > $1.date }) { a in
                    VStack(alignment: .leading) {
                        ActivityHistoryRow(activity: a)
                        if a.isEffective {
                            HStack {
                                Button { correctingActivity = a } label: { Text("訂正する").frame(minHeight: 44) }
                                Button(role: .destructive) { cancellingActivity = a } label: { Text("取り消す").frame(minHeight: 44) }
                            }.buttonStyle(.bordered)
                        } else if ActivityAudit.canRestore(a, among: customer.activities) {
                            Button { restoringActivity = a } label: { Label("取り消した活動を復元", systemImage: "arrow.uturn.backward").frame(minHeight: 44) }.buttonStyle(.bordered)
                        }
                    }
                }
            }
            Section {
                if customer.activities.isEmpty {
                    Button("顧客を削除", role: .destructive) { deleting=true }
                } else {
                    Text("活動履歴がある顧客は、監査履歴を守るため削除できません。活動の誤りは訂正・取り消しで対応してください。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }.navigationTitle(customer.company)
        .toolbar { Button("編集") { editing=true } }
        .sheet(isPresented: $editing) { CustomerEditor(customer: customer) }
        .sheet(isPresented: $recording) { ActivityEditor(customer: customer) }
        .sheet(item: $correctingActivity) { ActivityEditor(customer: customer, original: $0) }
        .sheet(item: $cancellingActivity) { CancelActivityView(activity: $0) }
        .sheet(item: $restoringActivity) { RestoreActivityView(activity: $0) }
        .confirmationDialog("活動履歴のない顧客を削除しますか？", isPresented: $deleting, titleVisibility: .visible) {
            Button("削除する", role: .destructive) {
                guard customer.activities.isEmpty else { errorMessage = "活動履歴がある顧客は削除できません。"; return }
                context.delete(customer)
                do { try context.save(); dismiss() } catch { context.rollback(); errorMessage=error.localizedDescription }
            }
        } message: { Text("この操作は取り消せません。必要なデータは先にCSVで出力してください。") }
        .alert("保存できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage=nil } })) {
            Button("閉じる", role: .cancel) {}
        } message: { Text(errorMessage ?? "") }
    }
    private func row(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value.trimmingCharacters(in: .whitespaces).isEmpty ? "未入力" : value).textSelection(.enabled)
        }
    }
}
