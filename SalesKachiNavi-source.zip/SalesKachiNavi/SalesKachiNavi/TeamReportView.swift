import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct TeamReportView: View {
    @Query private var customers: [Customer]
    @Query private var activities: [SalesActivity]
    @Query(sort: \SalesPerson.name) private var people: [SalesPerson]
    @State private var period = "今月"
    @State private var from = Calendar.current.startOfDay(for: Date())
    @State private var through = Date()
    @State private var csv = CSVDocument()
    @State private var excel = ExcelDocument()
    @State private var exportingCSV = false
    @State private var exportingExcel = false
    @State private var exportError: String?
    private var validRange: Bool { Calendar.current.startOfDay(for: from) <= Calendar.current.startOfDay(for: through) }
    private var interval: DateInterval? {
        let calendar = Calendar.current
        if period == "全期間" { return nil }
        if period == "指定期間" {
            let start = calendar.startOfDay(for: from)
            let end = calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: through))!
            return DateInterval(start: start, end: max(start, end))
        }
        return calendar.dateInterval(of: period == "今日" ? .day : period == "今週" ? .weekOfYear : .month, for: Date())
    }
    private var records: [SalesActivity] { SalesKPI.filtered(activities, interval: interval) }
    private var historyRecords: [SalesActivity] {
        guard let interval else { return activities }
        return activities.filter { $0.date >= interval.start && $0.date < interval.end }
    }
    private var periodLabel: String {
        guard let interval else { return "全期間" }
        return "\(interval.start.formatted(date: .numeric, time: .omitted))〜\(interval.end.addingTimeInterval(-1).formatted(date: .numeric, time: .omitted))（\(TimeZone.current.identifier)）"
    }
    var body: some View {
        List {
            Section("会社・案件の金額（全顧客の現在値）") {
                ReadableValue("案件見込額合計", value: DealMoney.total(customers.map(\.expectedDealAmountYen)))
                ReadableValue("受注額合計", value: DealMoney.total(customers.map(\.orderAmountYen)))
                Text("未設定：見込額 \(customers.filter { $0.expectedDealAmountYen == nil }.count)件／受注額 \(customers.filter { $0.orderAmountYen == nil }.count)件。担当者成果金額とは別です。下の活動期間では絞り込みません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("集計期間") {
                Picker("期間", selection: $period) {
                    ForEach(["今日", "今週", "今月", "全期間", "指定期間"], id: \.self) { Text($0) }
                }
                if period == "指定期間" {
                    DatePicker("開始日", selection: $from, displayedComponents: .date)
                    DatePicker("終了日（この日を含む）", selection: $through, displayedComponents: .date)
                }
                if period == "指定期間" && !validRange {
                    Text("終了日は開始日以降にしてください。").foregroundStyle(.red)
                } else { Text(periodLabel).font(.caption).foregroundStyle(.secondary) }
            }
            if period != "指定期間" || validRange {
                Section("チーム全体（未割当を含む）") { metrics(SalesMetrics(records)) }
                ForEach(SalesKPI.groups(records, people: people)) { group in
                    Section {
                        DisclosureGroup {
                            metrics(group.metrics)
                            if group.id != "unassigned" { Text("担当者ID：\(group.id)").font(.caption).textSelection(.enabled) }
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(group.name) · \(group.status)").font(.headline)
                                Text("架電 \(group.metrics.calls) · アポ \(group.metrics.appointments) · 商談 \(group.metrics.meetings) · 受注 \(group.metrics.orders)").font(.caption)
                                Text("担当者成果金額 \(SalesKPI.money(group.metrics.reward))").foregroundStyle(.teal)
                            }
                        }
                    }
                }
                Section("この期間を出力") {
                    Button("担当者別KPI・成果金額 CSV") {
                        csv = CSVDocument(text: CSVExport.table(SalesKPI.rows(records, people: people, period: periodLabel)))
                        exportingCSV = true
                    }
                    Button("集計と活動明細 Excel") {
                        excel = ExcelDocument(data: ExcelExport.workbook(sheets: [
                            ("担当者別集計", SalesKPI.rows(records, people: people, period: periodLabel)),
                            ("活動明細（履歴含む）", CSVExport.activityRows(historyRecords)),
                            ("会社案件金額", DealMoney.rows(customers)),
                            ("集計の定義", [[SalesKPI.definitions]])]))
                        exportingExcel = true
                    }
                }
            }
            Section("集計の見方") { Text(SalesKPI.definitions).font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("担当者別集計")
        .fileExporter(isPresented: $exportingCSV, document: csv, contentType: .commaSeparatedText, defaultFilename: "SalesKachiNavi-KPI") { result in
            if case .failure(let e) = result { exportError = e.localizedDescription }
        }
        .fileExporter(isPresented: $exportingExcel, document: excel, contentType: ExcelDocument.readableContentTypes[0], defaultFilename: "SalesKachiNavi-KPI") { result in
            if case .failure(let e) = result { exportError = e.localizedDescription }
        }
        .alert("出力できませんでした", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError = nil } })) {
            Button("閉じる", role: .cancel) {}
        } message: { Text(exportError ?? "") }
    }
    private func metrics(_ m: SalesMetrics) -> some View {
        VStack(spacing: 8) {
            ReadableValue("活動数", value: String(m.records))
            ReadableValue("架電数", value: String(m.calls))
            ReadableValue("接続数", value: String(m.connections))
            ReadableValue("担当者接続数", value: String(m.decisionContacts))
            ReadableValue("ヒアリング数", value: String(m.hearings))
            ReadableValue("電話アポ数", value: String(m.phoneAppointments))
            ReadableValue("アポ合計", value: String(m.appointments))
            ReadableValue("商談数", value: String(m.meetings))
            ReadableValue("受注数", value: String(m.orders))
            ReadableValue("接続率", value: m.rate(m.connections, m.calls))
            ReadableValue("電話アポ率", value: m.rate(m.phoneAppointments, m.calls))
            ReadableValue("受注／商談比率", value: m.rate(m.orders, m.meetings))
            ReadableValue("アポ成果金額", value: SalesKPI.money(m.appointmentReward))
            ReadableValue("商談成果金額", value: SalesKPI.money(m.meetingReward))
            ReadableValue("受注成果金額", value: SalesKPI.money(m.orderReward))
            ReadableValue("担当者成果金額計", value: SalesKPI.money(m.reward)).font(.headline)
            if m.missingPrices > 0 {
                Text("単価記録なし：\(m.missingPrices)件。件数には含め、成果金額には含めていません。")
                    .font(.caption).foregroundStyle(.orange)
            }
        }.padding(.vertical, 8)
    }
}
