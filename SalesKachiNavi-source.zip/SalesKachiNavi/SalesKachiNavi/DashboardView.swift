import SwiftUI
import SwiftData
import Charts

struct DashboardView: View {
    @Query private var activities: [SalesActivity]
    @Query private var customers: [Customer]
    @State private var period = "今日"
    @State private var adding = false
    private let periods = ["今日", "今週", "今月"]
    var interval: DateInterval {
        Calendar.current.dateInterval(of: period == "今日" ? .day : period == "今週" ? .weekOfYear : .month, for: Date())!
    }
    var records: [SalesActivity] { activities.filter { $0.isEffective && $0.date >= interval.start && $0.date < interval.end } }
    var calls: [SalesActivity] { records.filter { $0.kind == "電話" } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        Label("営業マン勝ちナビ", systemImage: "chart.line.uptrend.xyaxis").font(.subheadline.bold())
                        Spacer()
                        Text("SALES JOURNAL").font(.caption2.bold()).tracking(1)
                    }.foregroundStyle(.white.opacity(0.8))
                    Text("今日の一歩を、\n次の成果へ。")
                        .font(.system(.largeTitle, design: .rounded, weight: .bold))
                        .foregroundStyle(.white).accessibilityAddTraits(.isHeader)
                    Text(Date(), format: .dateTime.year().month().day().weekday())
                        .font(.caption).foregroundStyle(.white.opacity(0.75))
                    HStack(alignment: .bottom, spacing: 6) {
                        Text(records.count.formatted()).font(.system(size: 56, weight: .bold, design: .rounded))
                        Text("件の活動 / \(period)").font(.subheadline).padding(.bottom, 10)
                        Spacer()
                        Image(systemName: "chart.bar.fill").font(.system(size: 44)).foregroundStyle(.white.opacity(0.25))
                    }.foregroundStyle(.white)
                    Button { adding = true } label: {
                        HStack {
                            Image(systemName: "person.badge.plus")
                            Text("顧客・案件を登録").fontWeight(.bold)
                            Spacer()
                            Image(systemName: "arrow.right")
                        }.padding(16).foregroundStyle(Color(red: 0.05, green: 0.20, blue: 0.23))
                            .background(Color(red: 0.45, green: 0.92, blue: 0.78), in: RoundedRectangle(cornerRadius: 16))
                    }.buttonStyle(.plain)
                }.padding(24).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [Color(red: 0.05, green: 0.16, blue: 0.23), Color(red: 0.07, green: 0.31, blue: 0.34)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
                Text("営業活動をひと目で").font(.title2.bold())
                Picker("集計期間", selection: $period) { ForEach(periods, id: \.self) { Text($0) } }.pickerStyle(.segmented)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140))], spacing: 12) {
                    metric("架電", calls.count, "phone")
                    metric("接続", calls.filter(\.connected).count, "phone.connection")
                    metric("担当者接続", calls.filter(\.decisionContact).count, "person.crop.circle")
                    metric("ヒアリング", calls.filter(\.hearing).count, "text.bubble")
                    metric("電話アポ獲得", calls.filter(\.appointment).count, "calendar.badge.plus")
                    metric("商談記録", records.filter { $0.kind == "商談" }.count, "person.2")
                    metric("受注記録", records.filter { $0.kind == "受注" }.count, "checkmark.seal")
                    metric("HOT顧客（現在）", customers.filter { $0.temperature == "HOT" }.count, "flame")
                }
                GroupBox("電話の成果") {
                    VStack(spacing: 12) {
                        LabeledContent("接続率", value: rate(calls.filter(\.connected).count))
                        LabeledContent("アポ率", value: rate(calls.filter(\.appointment).count))
                        Text("接続率＝接続した電話÷架電数。アポ率＝アポを獲得した電話÷架電数。架電が0件の期間は「—」。商談・受注は活動記録の件数です。").font(.caption).foregroundStyle(.secondary)
                    }.padding(8)
                }
                GroupBox("直近7日間の架電") {
                    Chart(0..<7, id: \.self) { offset in
                        let day = Calendar.current.date(byAdding: .day, value: offset - 6, to: Calendar.current.startOfDay(for: Date()))!
                        let count = activities.filter { $0.isEffective && $0.kind == "電話" && Calendar.current.isDate($0.date, inSameDayAs: day) }.count
                        BarMark(x: .value("日", day, unit: .day), y: .value("架電数", count)).foregroundStyle(.teal)
                    }.chartYScale(domain: 0...max(1, maxCalls)).frame(height: 180).padding(8)
                }
                if customers.isEmpty {
                    Button("最初の顧客を登録") { adding=true }.buttonStyle(.borderedProminent)
                    Text("顧客を登録し、顧客詳細から営業活動を記録すると集計されます。").foregroundStyle(.secondary)
                }
            }.padding(24).frame(maxWidth: 1000)
        }.navigationTitle("ホーム")
        .sheet(isPresented: $adding) { CustomerEditor() }
    }
    var maxCalls: Int {
        (0..<7).map { offset in
            let day=Calendar.current.date(byAdding: .day, value: -offset, to: Date())!
            return activities.filter { $0.isEffective && $0.kind == "電話" && Calendar.current.isDate($0.date, inSameDayAs: day) }.count
        }.max() ?? 1
    }
    private func rate(_ n: Int) -> String { calls.isEmpty ? "—" : String(format: "%.1f%%", Double(n) / Double(calls.count) * 100) }
    private func metric(_ name: String, _ value: Int, _ icon: String) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: icon).font(.title3).foregroundStyle(.teal)
                    .frame(width: 40, height: 40)
                    .background(.teal.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                Spacer()
                Text("件").font(.caption).foregroundStyle(.secondary)
            }
            Text(value.formatted()).font(.system(size: 36, weight: .bold, design: .rounded))
            Text(name).font(.subheadline).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(.background, in: RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(.teal.opacity(0.14)))
    }
}
struct FollowUpsView: View {
    @Query(sort: \Customer.followUp) private var customers: [Customer]
    var pending: [Customer] { customers.filter { $0.followUp != nil } }
    var body: some View {
        List {
            Text("予定の確認と完了は顧客詳細で行えます。現在はアプリ内の予定一覧です。通知はまだ送信しません。").font(.caption).foregroundStyle(.secondary)
            ForEach(pending) { c in
                NavigationLink { CustomerDetail(customer: c) } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        CustomerRow(customer: c)
                        if !c.followUpNote.isEmpty { Text(c.followUpNote).font(.subheadline) }
                        if let date=c.followUp, date < Date() { Text("予定時刻を過ぎています").font(.caption).foregroundStyle(.orange) }
                    }
                }
            }
            if pending.isEmpty { ContentUnavailableView("再連絡の予定はありません", systemImage: "calendar", description: Text("顧客の編集画面から予定を登録できます。")) }
        }.navigationTitle("再連絡")
    }
}
