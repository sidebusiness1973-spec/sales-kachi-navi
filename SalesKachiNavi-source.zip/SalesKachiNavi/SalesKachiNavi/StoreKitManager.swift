import Foundation
import Observation
import StoreKit

enum StoreProductID {
    static let monthly = "com.saleskachinavi.pro.monthly"
    static let yearly = "com.saleskachinavi.pro.yearly"
    static let all: Set<String> = [monthly, yearly]
}

enum StoreLoadingState: Equatable {
    case idle
    case loading
    case loaded
    case failed(String)
}

enum PurchaseOutcome: Equatable {
    case purchased
    case pending
    case cancelled
    case failed(String)
}

enum StoreKitManagerError: LocalizedError {
    case failedVerification
    case productNotFound
    case timedOut

    var errorDescription: String? {
        switch self {
        case .failedVerification:
            "App Storeで購入情報を確認できませんでした。"
        case .productNotFound:
            "選択した商品を取得できませんでした。"
        case .timedOut:
            "App Storeへの接続がタイムアウトしました。時間をおいて再度お試しください。"
        }
    }
}

@MainActor
@Observable
final class StoreKitManager {
    private(set) var products: [Product] = []
    private(set) var isPro = false
    private(set) var loadingState: StoreLoadingState = .idle
    private(set) var purchaseOutcome: PurchaseOutcome?
    private(set) var activeProductID: String?

    private var updatesTask: Task<Void, Never>?
    private var hasStarted = false

    func start() async {
        guard !hasStarted else { return }
        hasStarted = true
        observeTransactionUpdates()
        async let products: Void = loadProducts()
        async let entitlement: Void = refreshEntitlements()
        _ = await (products, entitlement)
    }

    func loadProducts() async {
        loadingState = .loading
        do {
            let fetched = try await withThrowingTaskGroup(of: [Product].self) { group in
                group.addTask {
                    try await Product.products(for: StoreProductID.all)
                }
                group.addTask {
                    try await Task.sleep(for: .seconds(15))
                    throw StoreKitManagerError.timedOut
                }
                guard let result = try await group.next() else {
                    throw StoreKitManagerError.productNotFound
                }
                group.cancelAll()
                return result
            }
            products = fetched.sorted { lhs, rhs in
                if lhs.id == StoreProductID.monthly { return true }
                if rhs.id == StoreProductID.monthly { return false }
                return lhs.displayName < rhs.displayName
            }
            loadingState = products.isEmpty
                ? .failed("購入プランを取得できませんでした。時間をおいて再度お試しください。")
                : .loaded
        } catch {
            products = []
            loadingState = .failed(error.localizedDescription)
        }
    }

    func product(for id: String) -> Product? {
        products.first { $0.id == id }
    }

    func purchase(productID: String) async {
        purchaseOutcome = nil
        guard let product = product(for: productID) else {
            purchaseOutcome = .failed(StoreKitManagerError.productNotFound.localizedDescription)
            return
        }

        do {
            switch try await product.purchase() {
            case .success(let verification):
                let transaction = try verified(verification)
                await transaction.finish()
                await refreshEntitlements()
                purchaseOutcome = .purchased
            case .pending:
                purchaseOutcome = .pending
            case .userCancelled:
                purchaseOutcome = .cancelled
            @unknown default:
                purchaseOutcome = .failed("購入結果を確認できませんでした。")
            }
        } catch {
            purchaseOutcome = .failed(error.localizedDescription)
        }
    }

    func restorePurchases() async {
        purchaseOutcome = nil
        do {
            try await AppStore.sync()
            await refreshEntitlements()
            purchaseOutcome = isPro
                ? .purchased
                : .failed("復元できる有効なPersonal Pro購入が見つかりませんでした。")
        } catch {
            purchaseOutcome = .failed(error.localizedDescription)
        }
    }

    func refreshEntitlements() async {
        var entitledProductID: String?

        for await result in Transaction.currentEntitlements {
            do {
                let transaction = try verified(result)
                guard StoreProductID.all.contains(transaction.productID),
                      transaction.revocationDate == nil,
                      transaction.expirationDate.map({ $0 > Date() }) ?? true else {
                    continue
                }
                entitledProductID = transaction.productID
            } catch {
                continue
            }
        }

        activeProductID = entitledProductID
        isPro = entitledProductID != nil
    }

    func clearPurchaseOutcome() {
        purchaseOutcome = nil
    }

    private func observeTransactionUpdates() {
        updatesTask = Task { [weak self] in
            for await result in Transaction.updates {
                guard !Task.isCancelled else { return }
                do {
                    let transaction = try Self.verifiedTransaction(result)
                    await transaction.finish()
                } catch {
                    // Unverified transactions never grant access.
                }
                await self?.refreshEntitlements()
            }
        }
    }

    nonisolated private static func verifiedTransaction(
        _ result: VerificationResult<Transaction>
    ) throws -> Transaction {
        switch result {
        case .verified(let transaction):
            transaction
        case .unverified:
            throw StoreKitManagerError.failedVerification
        }
    }

    private func verified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .verified(let value):
            value
        case .unverified:
            throw StoreKitManagerError.failedVerification
        }
    }
}
