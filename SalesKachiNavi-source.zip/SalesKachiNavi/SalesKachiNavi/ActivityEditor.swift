import SwiftUI
import SwiftData

struct ActivityEditor: View {
    @Environment(StoreKitManager.self) private var store
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \SalesPerson.name) private var people: [SalesPerson]
    @Query private var allActivities: [SalesActivity]
    @State private var salesPersonID: UUID?
    @State private var reason = ""
    @State private var duplicateCandidates: [SalesActivity] = []
    @State private var showingDuplicates = false
    @State private var isSaving = false
    @State private var showPro = false
    let original: SalesActivity?
    private var preservingSnapshot: Bool { original != nil && salesPersonID == original?.salesPersonID }
    private var canSave: Bool {
        !isSaving && (preservingSnapshot || selectedPerson != nil) &&
        (original == nil || (!reason.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && original!.isEffective))
    }
    private var selectablePeople: [SalesPerson] {
        let correctionPeople = people.filter { $0.isActive || $0.id == original?.salesPersonID }
        guard original == nil, !store.isPro else { return correctionPeople }
        guard let first = people.min(by: { $0.createdAt < $1.createdAt }), first.isActive else { return [] }
        return [first]
    }
    private var selectedPerson: SalesPerson? { selectablePeople.first { $0.id == salesPersonID && $0.isActive } }
    let customer: Customer
    @State private var date = Date()
    @State private var kind = "電話"
    @State private var outcome = "不在"
    @State private var respondent = ""
    @State private var note = ""
    @State private var connected = false
    @State private var decisionContact = false
    @State private var hearing = false
    @State private var appointment = false
    @State private var setFollowUp = false
    @State private var followUp = Date().addingTimeInterval(86400)
    @State private var followUpNote = ""
    @State private var errorMessage: String?
    init(customer: Customer, original: SalesActivity? = nil) {
        self.customer = customer
        self.original = original
        _salesPersonID = State(initialValue: original?.salesPersonID)
        _date = State(initialValue: original?.date ?? Date())
        _kind = State(initialValue: original?.kind ?? "電話")
        _outcome = State(initialValue: original?.outcome ?? "不在")
        _respondent = State(initialValue: original?.respondent ?? "")
        _note = State(initialValue: original?.note ?? "")
        _connected = State(initialValue: original?.connected ?? false)
        _decisionContact = State(initialValue: original?.decisionContact ?? false)
        _hearing = State(initialValue: original?.hearing ?? false)
        _appointment = State(initialValue: original?.appointment ?? false)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section(customer.company) {
                    Picker("営業担当者（社内）", selection: $salesPersonID) {
                        Text(original?.salesPersonID == nil && original != nil ? "未割当（元の記録を維持）" : "選択してください").tag(nil as UUID?)
                        if let original, let id = original.salesPersonID, !people.contains(where: { $0.id == id }) {
                            Text(original.salesPersonNameSnapshot ?? "元の担当者").tag(Optional(id))
                        }
                        ForEach(selectablePeople) { p in
                            Text("\(p.name)（\(p.department.isEmpty ? String(p.id.uuidString.prefix(6)) : p.department)）").tag(Optional(p.id))
                        }
                    }
                    if preservingSnapshot, let original {
                        Text(original.hasPriceSnapshot ? "元の活動に保存された単価を引き継ぎます。現在の担当者単価では再計算しません。" : "元の記録に単価がないため、訂正後も単価未設定として保持します。")
                            .font(.caption).foregroundStyle(.secondary)
                    } else if let p = selectedPerson {
                        VStack(alignment: .leading, spacing: 4) {
                            ReadableValue("アポ単価", value: SalesKPI.money(SalesKPI.decimal(p.appointmentUnitPrice)))
                            ReadableValue("商談単価", value: SalesKPI.money(SalesKPI.decimal(p.meetingUnitPrice)))
                            ReadableValue("受注単価", value: SalesKPI.money(SalesKPI.decimal(p.orderUnitPrice)))
                        }
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text("有効な社内担当者を選択してください。担当者がいない場合は「担当者管理」で登録できます。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text("単価は保存時点で固定されます。活動日時を過去にしても、その日の単価を復元するものではありません。アポ獲得は電話のチェックか「アポ」のどちらかで1回だけ記録してください。")
                        .font(.caption).foregroundStyle(.secondary)
                    if original == nil && !store.isPro && people.count > 1 {
                        Button("他の担当者を利用するにはPersonal Proが必要です") {
                            showPro = true
                        }
                        .font(.caption)
                    }
                    DatePicker("活動日時", selection: $date, in: ...Date())
                    Picker("活動種別", selection: $kind) { ForEach(SalesOptions.kinds, id: \.self) { Text($0 == "アポ" ? "アポ獲得" : $0).tag($0) } }
                    if kind == "電話" {
                        Picker("電話結果", selection: $outcome) { ForEach(SalesOptions.outcomes, id: \.self) { Text($0) } }
                        TextField("実際の対応者・役割", text: $respondent)
                        Toggle("誰かと会話できた（受付を含む）", isOn: $connected)
                        Toggle("担当者と会話できた", isOn: $decisionContact)
                        Toggle("ヒアリング実施", isOn: $hearing)
                        Toggle("アポ獲得", isOn: $appointment)
                    }
                    TextField("会話内容・結果・次の行動", text: $note, axis: .vertical).lineLimit(3...8)
                }
                if original != nil {
                    Section("訂正理由（必須）") {
                        TextField("訂正する理由", text: $reason, axis: .vertical).lineLimit(2...5)
                        Text("元の内容と単価を履歴に残し、訂正版を新しい記録として保存します。元の記録は集計対象外になります。担当者を変える場合は、その担当者の現在の単価を訂正版に保存します。再連絡の予定は変更しません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                if original == nil {
                Section("再連絡") {
                    Toggle("次回の予定を更新", isOn: $setFollowUp)
                    if setFollowUp {
                        DatePicker("日時", selection: $followUp)
                        TextField("連絡の目的", text: $followUpNote, axis: .vertical)
                    }
                    Text("案件の進捗は、顧客の「編集」から変更できます。").font(.caption).foregroundStyle(.secondary)
                }
                }
            }.formStyle(.grouped)
            .navigationTitle(original == nil ? "営業活動を記録" : "営業活動を訂正")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button(original == nil ? "保存" : "訂正を保存") { requestSave() }.disabled(!canSave) }
            }
            .onChange(of: outcome) { _, value in
                connected = value != "不在"
                decisionContact = ["担当者接続", "興味なし", "再架電", "資料送付", "ヒアリング実施", "アポ獲得"].contains(value)
                hearing = value == "ヒアリング実施"
                appointment = value == "アポ獲得"
            }
            .sheet(isPresented: $showingDuplicates) {
                DuplicateActivityReview(candidates: duplicateCandidates) {
                    let approvedIDs = Set(duplicateCandidates.map(\.id))
                    showingDuplicates = false
                    requestSave(approvedIDs: approvedIDs)
                }
            }
            .sheet(isPresented: $showPro) {
                NavigationStack {
                    PersonalProView()
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) {
                                Button("閉じる") { showPro = false }
                            }
                        }
                }
            }
            .alert("保存できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage=nil } })) {
                Button("閉じる", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
        }
        #if os(macOS)
        .frame(minWidth: 520, minHeight: 580)
        #endif
    }
    private func requestSave(approvedIDs: Set<UUID> = []) {
        guard canSave else { return }
        let candidates = ActivityAudit.duplicates(in: allActivities, customerID: customer.id,
            personID: salesPersonID, kind: kind, appointment: appointment, date: date, excluding: original?.id)
        if !Set(candidates.map(\.id)).isSubset(of: approvedIDs) {
            duplicateCandidates = candidates
            showingDuplicates = true
            return
        }
        save(confirmedCandidates: candidates)
    }
    private func save(confirmedCandidates: [SalesActivity]) {
        guard canSave else { return }
        if !preservingSnapshot {
            guard let person = selectedPerson, SalesKPI.validPrices(person) else {
                errorMessage = "有効な担当者と正しい単価を設定してください。"; return
            }
        }
        isSaving = true
        let timestamp = Date()
        let a = SalesActivity()
        if preservingSnapshot, let original { a.inheritSnapshot(from: original) }
        else if let person = selectedPerson { a.captureSalesPerson(person, at: timestamp) }
        a.date=date; a.kind=kind; a.outcome=kind == "電話" ? outcome : ""; a.respondent=respondent; a.note=note
        if kind == "電話" {
            a.hearing=hearing; a.appointment=appointment
            a.decisionContact=decisionContact || hearing || appointment
            a.connected=connected || a.decisionContact
        }
        a.recordState = "active"
        if !confirmedCandidates.isEmpty {
            a.duplicateConfirmedAt = timestamp
            a.duplicateCandidateIDs = confirmedCandidates.map { $0.id.uuidString }.sorted().joined(separator: ",")
        }
        let previousState = original?.recordState
        let previousDate = original?.invalidatedAt
        let previousReason = original?.invalidationReason
        let previousReplacement = original?.replacedByActivityID
        let previousFollowUp = customer.followUp
        let previousFollowUpNote = customer.followUpNote
        let autosave = context.autosaveEnabled
        context.autosaveEnabled = false
        defer { context.autosaveEnabled = autosave }
        context.insert(a)
        a.customer = customer
        do {
            if let original {
                try ActivityAudit.correct(original, with: a, reason: reason, at: timestamp)
            } else if setFollowUp {
                customer.followUp=followUp; customer.followUpNote=followUpNote
            }
            try context.save()
            dismiss()
        }
        catch {
            // Remove only this unsaved insertion and restore this operation's mutations.
            a.customer = nil
            context.delete(a)
            if let original {
                original.recordState = previousState; original.invalidatedAt = previousDate
                original.invalidationReason = previousReason; original.replacedByActivityID = previousReplacement
            }
            customer.followUp = previousFollowUp; customer.followUpNote = previousFollowUpNote
            isSaving = false
            errorMessage=error.localizedDescription
        }
    }
}
