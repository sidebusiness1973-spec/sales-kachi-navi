import Foundation

extension SalesActivity {
    var isEffective: Bool {
        (recordState == nil || recordState == "active") && invalidatedAt == nil && replacedByActivityID == nil
    }
    var canRestore: Bool {
        recordState == "cancelled" && invalidatedAt != nil && replacedByActivityID == nil && restoredByActivityID == nil
    }
    var statusLabel: String {
        if recordState == "superseded" || replacedByActivityID != nil { return "訂正済み・集計対象外" }
        if !isEffective {
            return restoredByActivityID == nil ? "取り消し済み・集計対象外" : "取り消し履歴・別の記録で復元済み"
        }
        if restoresActivityID != nil { return "有効・復元した記録" }
        return replacesActivityID == nil ? "有効" : "有効・訂正版"
    }
    var achievementKind: String? {
        if countsAsAppointment { return "アポ" }
        return kind == "商談" || kind == "受注" ? kind : nil
    }
    func inheritSnapshot(from original: SalesActivity) {
        salesPersonID = original.salesPersonID
        salesPersonNameSnapshot = original.salesPersonNameSnapshot
        appointmentPriceSnapshot = original.appointmentPriceSnapshot
        meetingPriceSnapshot = original.meetingPriceSnapshot
        orderPriceSnapshot = original.orderPriceSnapshot
        pricesCapturedAt = original.pricesCapturedAt
    }
}

enum ActivityAudit {
    enum ValidationError: LocalizedError {
        case unavailable, duplicateReviewRequired
        var errorDescription: String? {
            switch self {
            case .unavailable: "この記録は操作できません。状態と理由を確認して、画面を開き直してください。"
            case .duplicateReviewRequired: "重複の可能性がある記録が増えました。もう一度内容を確認してください。"
            }
        }
    }
    static func cancel(_ activity: SalesActivity, reason: String, at date: Date = Date()) throws {
        let reason = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard activity.isEffective, !reason.isEmpty else { throw ValidationError.unavailable }
        activity.recordState = "cancelled"
        activity.invalidatedAt = date
        activity.invalidationReason = reason
    }
    static func correct(_ original: SalesActivity, with replacement: SalesActivity, reason: String, at date: Date = Date()) throws {
        let reason = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard original.isEffective, replacement.isEffective, original.id != replacement.id,
              replacement.replacesActivityID == nil, original.customer?.id == replacement.customer?.id,
              !reason.isEmpty else { throw ValidationError.unavailable }
        replacement.replacesActivityID = original.id
        replacement.correctionRecordedAt = date
        replacement.correctionReason = reason
        original.recordState = "superseded"
        original.invalidatedAt = date
        original.invalidationReason = reason
        original.replacedByActivityID = replacement.id
    }
    static func canRestore(_ original: SalesActivity, among records: [SalesActivity]) -> Bool {
        original.canRestore && original.customer != nil && !records.contains {
            $0.id != original.id && ($0.restoresActivityID == original.id || $0.replacesActivityID == original.id)
        }
    }
    static func restore(_ original: SalesActivity, among records: [SalesActivity], reason: String,
                        approvedDuplicateIDs: Set<UUID> = [], at timestamp: Date = Date()) throws -> SalesActivity {
        let reason = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard canRestore(original, among: records), let customer = original.customer, !reason.isEmpty else {
            throw ValidationError.unavailable
        }
        let candidates = duplicates(in: records, customerID: customer.id, personID: original.salesPersonID,
            kind: original.kind, appointment: original.appointment, date: original.date, excluding: original.id)
        guard Set(candidates.map(\.id)).isSubset(of: approvedDuplicateIDs) else { throw ValidationError.duplicateReviewRequired }
        let restored = SalesActivity()
        restored.date = original.date; restored.kind = original.kind; restored.outcome = original.outcome
        restored.respondent = original.respondent; restored.note = original.note
        restored.connected = original.connected; restored.decisionContact = original.decisionContact
        restored.hearing = original.hearing; restored.appointment = original.appointment
        restored.inheritSnapshot(from: original)
        restored.recordState = "active"
        restored.restoresActivityID = original.id
        restored.restoredAt = timestamp; restored.restorationReason = reason
        if !candidates.isEmpty {
            restored.duplicateConfirmedAt = timestamp
            restored.duplicateCandidateIDs = candidates.map { $0.id.uuidString }.sorted().joined(separator: ",")
        }
        original.restoredByActivityID = restored.id
        return restored
    }
    static let duplicateWindow: TimeInterval = 30 * 60
    static func achievement(kind: String, appointment: Bool) -> String? {
        if kind == "アポ" || (kind == "電話" && appointment) { return "アポ" }
        return kind == "商談" || kind == "受注" ? kind : nil
    }
    static func duplicates(in records: [SalesActivity], customerID: UUID, personID: UUID?,
                           kind: String, appointment: Bool, date: Date, excluding: UUID?) -> [SalesActivity] {
        guard let achievement = achievement(kind: kind, appointment: appointment) else { return [] }
        return records.filter {
            $0.isEffective && $0.id != excluding && $0.customer?.id == customerID &&
            $0.salesPersonID == personID && $0.achievementKind == achievement &&
            abs($0.date.timeIntervalSince(date)) <= duplicateWindow
        }.sorted { abs($0.date.timeIntervalSince(date)) < abs($1.date.timeIntervalSince(date)) }
    }
}
