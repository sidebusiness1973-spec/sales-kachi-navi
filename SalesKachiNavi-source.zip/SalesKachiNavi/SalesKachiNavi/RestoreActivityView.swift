import SwiftUI
import SwiftData

struct RestoreActivityView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var records: [SalesActivity]
    let activity: SalesActivity
    @State private var reason = ""
    @State private var confirming = false
    @State private var saving = false
    @State private var errorMessage: String?
    @State private var approvedCandidates: Set<UUID> = []
    private var eligible: Bool { ActivityAudit.canRestore(activity, among: records) }
    private var candidates: [SalesActivity] {
        guard let customer = activity.customer else { return [] }
        return ActivityAudit.duplicates(in: records, customerID: customer.id, personID: activity.salesPersonID,
            kind: activity.kind, appointment: activity.appointment, date: activity.date, excluding: activity.id)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("復元する活動") { ActivityHistoryRow(activity: activity) }
                Section("復元理由（必須）") {
                    TextField("例：別の記録と間違えて取り消したため", text: $reason, axis: .vertical).lineLimit(2...5)
                    Text("取り消し日時と理由を残し、同じ内容の有効な記録を作ります。元の担当者・活動日時・保存時単価で集計に戻ります。会社の案件金額や再連絡予定は変わりません。")
                        .font(.caption).foregroundStyle(.secondary)
                    if !activity.hasPriceSnapshot {
                        Text("元の記録に単価がないため、復元後も件数だけが集計されます。")
                            .font(.caption).foregroundStyle(.orange)
                    }
                }
                if !candidates.isEmpty {
                    Section("同じ成果がすでに登録されている可能性があります") {
                        Text("復元すると重複して集計される場合があります。以下の有効な記録を確認してください。")
                            .font(.caption).foregroundStyle(.secondary)
                        ForEach(candidates) { ActivityHistoryRow(activity: $0) }
                    }
                }
                if !eligible {
                    Section { Text("この記録は復元できません。訂正済みの旧版、すでに復元した記録、顧客のない記録は対象外です。") }
                }
                Section {
                    Button {
                        approvedCandidates = Set(candidates.map(\.id))
                        confirming = true
                    } label: {
                        Text(candidates.isEmpty ? "内容を確認して復元する" : "別の成果であることを確認して復元する")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }.buttonStyle(.borderedProminent)
                        .disabled(saving || !eligible || reason.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.formStyle(.grouped).navigationTitle("取り消した活動を復元")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("戻る") { dismiss() } } }
            .confirmationDialog("この活動を集計に戻しますか？", isPresented: $confirming, titleVisibility: .visible) {
                Button("理由を保存して復元", action: restore)
                Button("戻る", role: .cancel) {}
            } message: {
                Text("元の取り消し履歴は残ります。\n復元理由：\(reason)" + (approvedCandidates.isEmpty ? "" : "\n重複候補を確認した別成果として復元します。"))
            }
            .alert("復元できませんでした", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("閉じる", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
        }
        #if os(macOS)
        .frame(minWidth: 520, minHeight: 540)
        #endif
    }
    private func restore() {
        guard !saving else { return }
        saving = true
        let before = (activity.restoredByActivityID, activity.restoredAt, activity.restorationReason)
        let autosave = context.autosaveEnabled
        context.autosaveEnabled = false
        defer { context.autosaveEnabled = autosave }
        var inserted: SalesActivity?
        do {
            let restored = try ActivityAudit.restore(activity, among: records, reason: reason, approvedDuplicateIDs: approvedCandidates)
            inserted = restored
            context.insert(restored)
            restored.customer = activity.customer
            try context.save()
            dismiss()
        } catch {
            if let inserted { inserted.customer = nil; context.delete(inserted) }
            (activity.restoredByActivityID, activity.restoredAt, activity.restorationReason) = before
            saving = false
            errorMessage = error.localizedDescription
        }
    }
}
